#!/bin/bash
echo "Starting Python API for Skin Care Expert System..."
python3 api.py 